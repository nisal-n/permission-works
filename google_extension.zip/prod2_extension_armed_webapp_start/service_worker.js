// Background/Service Worker (MV3)
// - Login via Supabase Edge Function (app_users)
// - Forward batches to your ingest API with Bearer token
// - Forward single traces to Flask /api/trace with X-Call-Key (from /api/call_key)
// - Auto-fetch short-lived call_key from a logged-in web-app tab (uses that tab's cookies)

"use strict";

// ====== Config ======
const SUPABASE_URL = "https://ocigxexhtgpcxqaedled.supabase.co";
const LOGIN_FN_URL = `${SUPABASE_URL}/functions/v1/pw_login`;

// Function has Verify JWT ON → include anon key (public)
const SUPABASE_ANON_KEY =
  "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9."
+ "eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Im9jaWd4ZXhodGdwY3hxYWVkbGVkIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NTk5MjcyNzMsImV4cCI6MjA3NTUwMzI3M30."
+ "vLOaRA3jA7FybsV5VYobFiaHMshkAV5QKso9W2ZNLBY";

// Default web-app hosts to look for when fetching /api/call_key from a logged-in tab
const DEFAULT_APP_HOST_PATTERNS = [
  "http://127.0.0.1:5000/*",
  "http://localhost:5000/*",
  "http://13.50.226.94:5000/*",
  "http://13.60.52.121:5000/*"
  // Add your prod origin pattern(s) here, e.g.:
  // "https://your-app.example.com/*"
];

// ====== SW error logging ======
self.onunhandledrejection = (e) =>
  console.error("[PW][SW] Unhandled rejection:", e?.reason || e);
self.onerror = (msg, src, line, col, err) =>
  console.error("[PW][SW] Uncaught error:", msg, src, line, col, err);

// ====== Utilities ======
function fetchWithTimeout(resource, options = {}) {
  const { timeout = 15000 } = options; // default 15s
  const controller = new AbortController();
  const id = setTimeout(() => controller.abort(), timeout);
  return fetch(resource, { ...options, signal: controller.signal })
    .finally(() => clearTimeout(id));
}



// ====== Recording / action-click orchestration ======
const OFFSCREEN_DOCUMENT_PATH = "offscreen.html";
let recordingState = { active: false, tabId: null };
let armedTabId = null;

async function ensureOffscreenDocument() {
  const offscreenUrl = chrome.runtime.getURL(OFFSCREEN_DOCUMENT_PATH);
  const contexts = await chrome.runtime.getContexts({
    contextTypes: ['OFFSCREEN_DOCUMENT'],
    documentUrls: [offscreenUrl]
  });
  if (!contexts.length) {
    await chrome.offscreen.createDocument({
      url: OFFSCREEN_DOCUMENT_PATH,
      reasons: ['USER_MEDIA'],
      justification: 'Record the current tab when the extension action is clicked.'
    });
  }
}

async function getActiveTab() {
  const tabs = await chrome.tabs.query({ active: true, lastFocusedWindow: true });
  return tabs && tabs[0] ? tabs[0] : null;
}

async function sendPanelCommand(command, extra = {}) {
  try {
    await chrome.runtime.sendMessage({ type: 'PW_PANEL_COMMAND', command, ...extra });
  } catch (_) {}
}

async function getPageUrl(tabId) {
  try {
    const tab = await chrome.tabs.get(tabId);
    return tab?.url || '';
  } catch (_) {
    return '';
  }
}

async function startCombinedCaptureForTab(tabId, pageUrl = '') {
  if (!tabId) throw new Error('No target tab');
  await ensureOffscreenDocument();
  const streamId = await chrome.tabCapture.getMediaStreamId({ targetTabId: tabId });
  const rec = await chrome.runtime.sendMessage({
    type: 'PW_OFFSCREEN_START',
    streamId,
    meta: { tabId, pageUrl: pageUrl || await getPageUrl(tabId), prefix: 'permissionworks' }
  });
  if (!rec?.ok) throw new Error(rec?.error || 'Recording start failed');
  recordingState = { active: true, tabId };
  armedTabId = null;
  await chrome.storage.session.set({ pw_recording_active: true, pw_recording_tabId: tabId, pw_recording_armed_tabId: null });
  await sendPanelCommand('START_CAPTURE', { tabId });
}

async function stopCombinedCapture() {
  const tabId = recordingState.tabId;
  await sendPanelCommand('STOP_CAPTURE', { tabId });
  const rec = await chrome.runtime.sendMessage({ type: 'PW_OFFSCREEN_STOP' });
  if (!rec?.ok) throw new Error(rec?.error || 'Recording stop failed');
  recordingState = { active: false, tabId: null };
  await chrome.storage.session.set({ pw_recording_active: false, pw_recording_tabId: null });
}

async function armTabForWebappButtons(tab) {
  if (!tab?.id) throw new Error('No active tab');
  await chrome.scripting.executeScript({ target: { tabId: tab.id }, files: ['recorder_bridge.js'] });
  armedTabId = tab.id;
  await chrome.storage.session.set({ pw_recording_armed_tabId: tab.id });
  await sendPanelCommand('LOG', { text: 'Recording armed for this tab. Use the web app Start trace button.' });
}

chrome.action.onClicked.addListener(async (tab) => {
  try {
    const activeTab = tab || await getActiveTab();
    if (recordingState.active) {
      await stopCombinedCapture();
      return;
    }
    await armTabForWebappButtons(activeTab);
  } catch (e) {
    console.error('[PW][REC] action click failed:', e?.message || e);
    sendPanelCommand('LOG', { text: `Recording action failed: ${e?.message || e}` }).catch(() => {});
  }
});

// ====== Message Router ======
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  // --- Login against Edge Function (app_users) ---
  if (msg?.type === "PW_LOGIN_APPUSERS") {
    (async () => {
      try {
        const headers = { "Content-Type": "application/json" };
        if (SUPABASE_ANON_KEY) headers["Authorization"] = `Bearer ${SUPABASE_ANON_KEY}`;

        const res = await fetchWithTimeout(LOGIN_FN_URL, {
          method: "POST",
          headers,
          body: JSON.stringify({
            username_or_email: msg.login,
            password: msg.password
          }),
          timeout: 15000
        });

        const text = await res.text();
        if (!res.ok) throw new Error(text || `HTTP ${res.status}`);

        let data = {};
        try { data = text ? JSON.parse(text) : {}; } catch {}
        if (!data?.ok) throw new Error("Login failed");
        // data: { ok, token, ingestUrl, expiresAt, ... }
        sendResponse({ ok: true, ...data });
      } catch (e) {
        sendResponse({ ok: false, error: String(e?.message || e) });
      }
    })();
    return true; // keep channel open
  }

  // --- Batch forward to your ingest API with bearer token ---
  if (msg?.type === "PW_BATCH") {
    (async () => {
      const { endpoint, payload, token, signed } = msg;
      try {
        if (!token) throw new Error("Missing token");

        const baseHeaders = {
          "Content-Type": "application/json",
          "Authorization": `Bearer ${token}` // your API should validate this token
        };
        const extra = (signed && signed.headers) ? signed.headers : {};

        // Merge carefully: baseHeaders LAST so Authorization cannot be overridden
        const headers = { ...extra, ...baseHeaders };

        const res = await fetchWithTimeout(endpoint, {
          method: "POST",
          headers,
          body: JSON.stringify(payload),
          timeout: 15000
        });
        if (!res.ok) throw new Error(`HTTP ${res.status}`);
        sendResponse({ ok: true });
      } catch (e) {
        sendResponse({ ok: false, error: String(e?.message || e) });
      }
    })();
    return true;
  }

  // --- Single-trace forward to Flask (/api/trace) with detailed result ---
  if (msg?.type === "PW_TRACE") {
    (async () => {
      const { endpoint, payload, signed } = msg;
      try {
        const baseHeaders = { "Content-Type": "application/json" };
        const extra = (signed && signed.headers) ? signed.headers : {};
        // Expect X-Call-Key and X-PW-User inside extra
        const res = await fetchWithTimeout(endpoint, {
          method: "POST",
          headers: { ...baseHeaders, ...extra },
          body: JSON.stringify(payload),
          timeout: 15000
        });
        const text = await res.text().catch(() => "");
        if (!res.ok) {
          console.warn("[PW][TRACE] HTTP", res.status, text);
          sendResponse({ ok: false, status: res.status, body: text });
        } else {
          sendResponse({ ok: true, status: res.status, body: text });
        }
      } catch (e) {
        console.error("[PW][TRACE] network error:", e?.message || e);
        sendResponse({ ok: false, error: String(e?.message || e) });
      }
    })();
    return true;
  }

  // --- Auto-fetch call_key from a logged-in web-app tab (uses that tab's cookies) ---
  // --- Auto-fetch call_key from a logged-in web-app tab (uses that tab's cookies) ---
if (msg?.type === "PW_FETCH_CALL_KEY") {
  (async () => {
    try {
      const hosts = Array.isArray(msg.hosts) && msg.hosts.length
        ? msg.hosts
        : DEFAULT_APP_HOST_PATTERNS;

      // Prefer the active tab in the last focused window first
      let tabs = await chrome.tabs.query({ url: hosts, active: true, lastFocusedWindow: true });
      if (!tabs || tabs.length === 0) {
        // Fallback: any matching tab
        tabs = await chrome.tabs.query({ url: hosts });
      }
      if (!tabs || tabs.length === 0) {
        sendResponse({
          ok: false,
          error: "No matching web-app tab found. Open the app (logged in) on an allowed origin."
        });
        return;
      }

      const tabId = tabs[0].id;

      // Execute in the page context so cookies are included.
      const results = await chrome.scripting.executeScript({
        target: { tabId },
        args: ["/api/call_key"],
        func: (path) => {
          const url = new URL(path, location.origin).toString();
          // Inline timeout inside page context
          const controller = new AbortController();
          const id = setTimeout(() => controller.abort(), 15000);

          return fetch(url, {
            method: "POST",
            credentials: "include",
            headers: { "Content-Type": "application/json" },
            signal: controller.signal
          })
          .then(async (r) => {
            clearTimeout(id);
            const text = await r.text().catch(() => "");
            let json = {};
            try { json = text ? JSON.parse(text) : {}; } catch {}
            if (!r.ok) {
              return {
                ok: false,
                status: r.status,
                error: json?.error || json?.message || text || `HTTP ${r.status}`
              };
            }
            return { ok: true, data: json };
          })
          .catch((e) => ({ ok: false, error: String(e?.message || e) }));
        }
      });

      const first = results?.[0]?.result;
      if (!first?.ok) {
        sendResponse({
          ok: false,
          error: first?.error || "Call-key fetch failed",
          status: first?.status
        });
        return;
      }

      const { call_key, username, expires_at } = first.data || {};
      if (!call_key) {
        sendResponse({ ok: false, error: "No call_key in response" });
        return;
      }

      sendResponse({ ok: true, call_key, username, expires_at });
    } catch (e) {
      sendResponse({ ok: false, error: String(e?.message || e) });
    }
  })();
  // Keep the message channel open for the async response
  return true;
}





  if (msg?.type === 'PW_WEBAPP_BRIDGE_READY') {
    sendPanelCommand('LOG', { text: 'Web trace page connected for recording.' }).catch(() => {});
    sendResponse({ ok: true });
    return false;
  }

  if (msg?.type === 'PW_WEBAPP_TRACE_START') {
    (async () => {
      try {
        const tabId = sender?.tab?.id;
        if (!tabId) throw new Error('Missing sender tab');
        if (recordingState.active) {
          sendResponse({ ok: true, already: true });
          return;
        }
        if (armedTabId !== tabId) {
          throw new Error('Recording is not armed for this tab. Click the extension icon once first.');
        }
        await startCombinedCaptureForTab(tabId, msg.pageUrl || '');
        sendPanelCommand('LOG', { text: 'Recording started from web app Start trace.' }).catch(() => {});
        sendResponse({ ok: true });
      } catch (e) {
        sendPanelCommand('LOG', { text: `Recording start failed: ${e?.message || e}` }).catch(() => {});
        sendResponse({ ok: false, error: String(e?.message || e) });
      }
    })();
    return true;
  }

  if (msg?.type === 'PW_WEBAPP_TRACE_STOP') {
    (async () => {
      try {
        if (!recordingState.active) {
          sendResponse({ ok: true, idle: true });
          return;
        }
        await stopCombinedCapture();
        sendPanelCommand('LOG', { text: 'Recording stopped from web app Stop trace.' }).catch(() => {});
        sendResponse({ ok: true });
      } catch (e) {
        sendPanelCommand('LOG', { text: `Recording stop failed: ${e?.message || e}` }).catch(() => {});
        sendResponse({ ok: false, error: String(e?.message || e) });
      }
    })();
    return true;
  }

  if (msg?.type === "PW_RECORDING_LOG") {
    sendPanelCommand('LOG', { text: msg.text || 'Recording update.' }).catch(() => {});
    sendResponse({ ok: true });
    return false;
  }

  if (msg?.type === "PW_RECORDING_STATUS") {
    sendResponse({ ok: true, ...recordingState });
    return false;
  }

  // --- Unknown message type ---
  sendResponse({ ok: false, error: "Unknown message type" });
});
