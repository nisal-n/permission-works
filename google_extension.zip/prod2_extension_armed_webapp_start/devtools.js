chrome.devtools.panels.create("Permission Works", "", "panel.html", () => {});
