(function () {
  if (window.__pwRecorderBridgeLoaded) return;
  window.__pwRecorderBridgeLoaded = true;

  const isTracePage = () => /\/trace(\?|$)/i.test(location.pathname + location.search);

  function btnText(el) {
    return (el?.innerText || el?.textContent || '').trim().toLowerCase();
  }

  function isVisible(el) {
    if (!el) return false;
    const s = window.getComputedStyle(el);
    return s.display !== 'none' && s.visibility !== 'hidden' && el.offsetParent !== null;
  }

  function findButton(kind) {
    const wants = kind === 'start'
      ? ['start trace', 'start']
      : ['stop trace', 'stop'];
    const buttons = Array.from(document.querySelectorAll('button, input[type="button"], input[type="submit"], a[role="button"]'));
    return buttons.find((el) => {
      if (!isVisible(el)) return false;
      const t = btnText(el);
      return wants.some((w) => t === w || t.includes(w));
    }) || null;
  }

  async function notify(type) {
    try {
      await chrome.runtime.sendMessage({ type, pageUrl: location.href });
    } catch (_) {}
  }

  document.addEventListener('click', (ev) => {
    if (!isTracePage()) return;
    const target = ev.target && ev.target.closest ? ev.target.closest('button, input[type="button"], input[type="submit"], a[role="button"]') : null;
    if (!target) return;
    const startBtn = findButton('start');
    const stopBtn = findButton('stop');
    if (startBtn && target === startBtn) {
      setTimeout(() => notify('PW_WEBAPP_TRACE_START'), 0);
      return;
    }
    if (stopBtn && target === stopBtn) {
      setTimeout(() => notify('PW_WEBAPP_TRACE_STOP'), 0);
    }
  }, true);

  chrome.runtime.sendMessage({ type: 'PW_WEBAPP_BRIDGE_READY', pageUrl: location.href }).catch(() => {});
})();
