let mediaRecorder = null;
let stream = null;
let chunks = [];
let currentMeta = {};

function sanitize(name) {
  return String(name || 'recording').replace(/[^a-zA-Z0-9._-]+/g, '_').replace(/^_+|_+$/g, '') || 'recording';
}

async function uploadOrDownload(blob, meta) {
  const stamp = new Date().toISOString().replace(/[:.]/g, '-');
  const filename = sanitize(`${meta.prefix || 'permissionworks'}_${meta.tabId || 'tab'}_${stamp}.webm`);
  const tried = [];
  for (const endpoint of [
    'http://127.0.0.1:5000/api/save_extension_recording',
    'http://localhost:5000/api/save_extension_recording',
    'http://13.60.52.121:5000/api/save_extension_recording'
  ]) {
    try {
      const fd = new FormData();
      fd.append('video', blob, filename);
      fd.append('tab_id', String(meta.tabId || ''));
      fd.append('page_url', meta.pageUrl || '');
      const res = await fetch(endpoint, { method: 'POST', body: fd, credentials: 'include' });
      if (res.ok) {
        chrome.runtime.sendMessage({ type: 'PW_RECORDING_LOG', text: `Recording uploaded to ${endpoint}.` });
        return;
      }
      tried.push(`${endpoint} -> HTTP ${res.status}`);
    } catch (e) {
      tried.push(`${endpoint} -> ${e?.message || e}`);
    }
  }

  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  a.click();
  setTimeout(() => URL.revokeObjectURL(url), 60000);
  chrome.runtime.sendMessage({ type: 'PW_RECORDING_LOG', text: `Recording downloaded as ${filename}. ${tried.length ? 'Upload failed: ' + tried.join('; ') : ''}` });
}

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg?.type === 'PW_OFFSCREEN_START') {
    (async () => {
      try {
        if (mediaRecorder && mediaRecorder.state !== 'inactive') {
          sendResponse({ ok: false, error: 'Recording already active' });
          return;
        }
        currentMeta = msg.meta || {};
        chunks = [];
        stream = await navigator.mediaDevices.getUserMedia({
          audio: false,
          video: {
            mandatory: {
              chromeMediaSource: 'tab',
              chromeMediaSourceId: msg.streamId,
              maxWidth: 3840,
              maxHeight: 2160,
              maxFrameRate: 30
            }
          }
        });
        mediaRecorder = new MediaRecorder(stream, { mimeType: 'video/webm;codecs=vp9,opus' });
        mediaRecorder.ondataavailable = (e) => {
          if (e.data && e.data.size > 0) chunks.push(e.data);
        };
        mediaRecorder.onerror = (e) => {
          chrome.runtime.sendMessage({ type: 'PW_RECORDING_LOG', text: `Recording error: ${e?.error?.message || e?.message || 'unknown'}` });
        };
        mediaRecorder.onstop = async () => {
          try {
            const blob = new Blob(chunks, { type: 'video/webm' });
            await uploadOrDownload(blob, currentMeta);
          } catch (e) {
            chrome.runtime.sendMessage({ type: 'PW_RECORDING_LOG', text: `Recording save failed: ${e?.message || e}` });
          } finally {
            chunks = [];
            if (stream) {
              stream.getTracks().forEach((t) => t.stop());
              stream = null;
            }
            mediaRecorder = null;
          }
        };
        mediaRecorder.start(1000);
        sendResponse({ ok: true });
      } catch (e) {
        if (stream) {
          stream.getTracks().forEach((t) => t.stop());
          stream = null;
        }
        mediaRecorder = null;
        sendResponse({ ok: false, error: String(e?.message || e) });
      }
    })();
    return true;
  }

  if (msg?.type === 'PW_OFFSCREEN_STOP') {
    try {
      if (mediaRecorder && mediaRecorder.state !== 'inactive') {
        mediaRecorder.stop();
        sendResponse({ ok: true });
      } else {
        sendResponse({ ok: true, idle: true });
      }
    } catch (e) {
      sendResponse({ ok: false, error: String(e?.message || e) });
    }
    return true;
  }
});
