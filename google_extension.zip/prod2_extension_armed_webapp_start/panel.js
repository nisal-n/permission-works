(function () {
  const $ = (sel) => document.querySelector(sel);

  // ---- Config (trace endpoint) ----
  const TRACE_ENDPOINT = "http://127.0.0.1:5000/api/trace";

  // ---------------------------
  // HMAC + header helpers
  // ---------------------------
  async function sha256Hex(bytesOrString) {
    const bytes = typeof bytesOrString === "string"
      ? new TextEncoder().encode(bytesOrString)
      : (bytesOrString || new Uint8Array());
    const buf = await crypto.subtle.digest("SHA-256", bytes);
    return Array.from(new Uint8Array(buf)).map(b => b.toString(16).padStart(2, "0")).join("");
  }

  async function hmacHex(keyRaw, msg) {
    const key = await crypto.subtle.importKey(
      "raw",
      new TextEncoder().encode(keyRaw),
      { name: "HMAC", hash: "SHA-256" },
      false,
      ["sign"]
    );
    const sigBuf = await crypto.subtle.sign("HMAC", key, new TextEncoder().encode(msg));
    return Array.from(new Uint8Array(sigBuf)).map(b => b.toString(16).padStart(2, "0")).join("");
  }

  /**
   * Compose headers for /api/trace:
   * - X-Call-Key: short-lived token issued by the web app
   * - X-PW-User: username (must match web-app user)
   * - Integrity: X-Timestamp + X-Signature (HMAC over ts|METHOD|PATH|sha256(body))
   */
  async function signedHeaders(method, path, bodyBytes) {
    const [{ pw_username }, { pw_callKey, pw_webUser, pw_callKeyExp }] = await Promise.all([
      chrome.storage.session.get(["pw_username"]),
      chrome.storage.local.get(["pw_callKey", "pw_webUser", "pw_callKeyExp"])
    ]);

    const userForSigning = pw_webUser || pw_username;
    if (!userForSigning || !pw_callKey) return {};

    const nowSec = Math.floor(Date.now() / 1000);
    if (pw_callKeyExp && nowSec >= pw_callKeyExp) return {};

    const ts = String(nowSec);
    const bodyHash = await sha256Hex(bodyBytes);
    const msg = `${ts}|${method.toUpperCase()}|${path}|${bodyHash}`;
    const sig = await hmacHex(pw_callKey, msg);

    return {
      "X-Call-Key": pw_callKey,
      "X-PW-User": userForSigning,
      "X-Timestamp": ts,
      "X-Signature": sig
    };
  }

  // ---------------------------
  // Call-key helpers
  // ---------------------------
  async function clearCallKey() {
    await chrome.storage.local.remove(["pw_callKey", "pw_webUser", "pw_callKeyExp"]);
  }

  // Auto-fetch call key (and web username) from a logged-in Web tab
  // If force=true, always refetch (SW prefers the active tab in focused window)
  async function ensureCallKeyAuto(force = false) {
    const { pw_callKey, pw_callKeyExp } = await chrome.storage.local.get(["pw_callKey", "pw_callKeyExp"]);
    const nowSec = Math.floor(Date.now() / 1000);
    if (!force && pw_callKey && (!pw_callKeyExp || nowSec < pw_callKeyExp)) return; // already valid

    const resp = await chrome.runtime.sendMessage({
      type: "PW_FETCH_CALL_KEY",
      hosts: ["http://127.0.0.1:5000/*", "http://localhost:5000/*", "http://13.50.226.94:5000/*", "http://oasispro-crystalworks.co.uk:5000/*","http://13.60.52.121:5000/*"],
    });
    if (resp?.ok && resp.call_key) {
      await chrome.storage.local.set({
        pw_callKey: resp.call_key,
        pw_webUser: resp.username || null,
        pw_callKeyExp: resp.expires_at || null
      });
      log(`Call key fetched for ${resp.username || "unknown"}.`);
    } else {
      log(`Call key fetch failed: ${resp?.error || "unknown"}`);
    }
  }

  async function refreshCallKeyIfNeeded() {
    const { pw_callKey, pw_callKeyExp } = await chrome.storage.local.get(["pw_callKey", "pw_callKeyExp"]);
    const nowSec = Math.floor(Date.now() / 1000);
    if (!pw_callKey || (pw_callKeyExp && nowSec >= pw_callKeyExp)) {
      await ensureCallKeyAuto(true);
    }
  }

  // Periodic refresh loop while capturing (stay ahead of short TTL)
  let callKeyTimer = null;
  function startCallKeyRefreshLoop() {
    stopCallKeyRefreshLoop();
    callKeyTimer = setInterval(() => {
      ensureCallKeyAuto(true).catch(() => {});
    }, 45000); // refresh ~every 45s
  }
  function stopCallKeyRefreshLoop() {
    if (callKeyTimer) { clearInterval(callKeyTimer); callKeyTimer = null; }
  }

  // ---------------------------
  // UI elements
  // ---------------------------
  const loginEl = $("#login");
  const controlsEl = $("#controls");
  const uEl = $("#u");
  const pEl = $("#p");
  const signinBtn = $("#signin");
  const loginMsg = $("#loginMsg");

  const startBtn = $("#start");
  const stopBtn = $("#stop");
  const flushBtn = $("#flush");
  const statusEl = $("#status");
  const countEl = $("#count");
  const pendingEl = $("#pending");
  const logEl = $("#log");
  const captureBodiesEl = $("#captureBodies");
  const onlyFailedEl = $("#onlyFailed");

  let enabled = false;
  let totalCaptured = 0;
  let queue = [];
  let flushTimer = null;
  let pageUrlCache = null;

  const BATCH_SIZE = 25;
  const FLUSH_MS = 5000;

  function log(msg) {
    const time = new Date().toLocaleTimeString();
    logEl.textContent += `[${time}] ${msg}\n`;
    logEl.scrollTop = logEl.scrollHeight;
  }

  // Resolve inspected page URL
  function resolvePageUrl() {
    return new Promise((resolve) => {
      if (!chrome.devtools?.inspectedWindow) return resolve(null);
      chrome.devtools.inspectedWindow.eval("location.href", (result, exceptionInfo) => {
        pageUrlCache = exceptionInfo?.isException ? null : (result || null);
        resolve(pageUrlCache);
      });
    });
  }

  // ---------------------------
  // Auth (panel/app_users)
  // ---------------------------
  async function ensureAuth() {
    const { pw_token, pw_exp, pw_ingestUrl } = await chrome.storage.session.get([
      "pw_token", "pw_exp", "pw_ingestUrl"
    ]);
    const now = Math.floor(Date.now() / 1000);
    const isValid = pw_token && pw_ingestUrl && (!pw_exp || now < (pw_exp - 30));
    loginEl.style.display = isValid ? "none" : "";
    controlsEl.style.display = isValid ? "" : "none";

    // opportunistically try to get/refresh the call key
    ensureCallKeyAuto(false).catch(() => {});
    return isValid;
  }

  async function doLogin() {
    loginMsg.textContent = "Signing in…";
    const login = uEl.value.trim();
    const password = pEl.value;

    async function loginViaWorker() {
      return chrome.runtime.sendMessage({ type: "PW_LOGIN_APPUSERS", login, password });
    }

    async function loginDirect() {
      const SUPABASE_URL = "https://ocigxexhtgpcxqaedled.supabase.co";
      const LOGIN_FN_URL = `${SUPABASE_URL}/functions/v1/pw_login`;
      const SUPABASE_ANON_KEY =
        "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9."
      + "eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Im9jaWd4ZXhodGdwY3hxYWVkbGVkIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NTk5MjcyNzMsImV4cCI6MjA3NTUwMzI3M30."
      + "vLOaRA3jA7FybsV5VYobFiaHMshkAV5QKso9W2ZNLBY";

      const headers = { "Content-Type": "application/json" };
      if (SUPABASE_ANON_KEY) headers["Authorization"] = `Bearer ${SUPABASE_ANON_KEY}`;

      const res = await fetch(LOGIN_FN_URL, {
        method: "POST",
        headers,
        body: JSON.stringify({ username_or_email: login, password })
      });
      const text = await res.text();
      if (!res.ok) throw new Error(text || `HTTP ${res.status}`);
      const data = JSON.parse(text);
      if (!data?.ok) throw new Error("Login failed");
      return { ok: true, ...data };
    }

    try {
      let out;
      try {
        out = await loginViaWorker();
      } catch (e) {
        if (String(e).includes("Extension context invalidated")) {
          await new Promise(r => setTimeout(r, 150));
          out = await loginViaWorker();
        } else {
          throw e;
        }
      }

      if (!out || out.ok === false) {
        console.warn("[PW] worker login failed, falling back to direct fetch:", out?.error);
        out = await loginDirect();
      }

      if (!out?.ok) throw new Error(out?.error || "Login failed");

      await chrome.storage.session.set({
        pw_token: out.token,
        pw_exp: out.expiresAt,
        pw_ingestUrl: out.ingestUrl,
        pw_name: out.name,
        pw_username: out.username,
        pw_email: out.email,
        pw_role: out.role
      });
      loginMsg.textContent = "Signed in";
      await ensureAuth();
    } catch (e) {
      loginMsg.textContent = e.message || String(e);
    }
  }

  signinBtn?.addEventListener("click", (e) => {
    e.preventDefault();
    doLogin();
  });

  // ---------------------------
  // Trace: single JSON per network call to TRACE_ENDPOINT
  // ---------------------------
  function toTracePayload(entry) {
    const { request } = entry;
    let bodyText = null;
    try {
      const reqPostData = request.postData;
      if (reqPostData && typeof reqPostData.text === "string") {
        bodyText = reqPostData.text;
      }
    } catch (_) {}
    const ts = entry.startedDateTime ? Date.parse(entry.startedDateTime) : Date.now();
    return { url: request.url, method: request.method, timeStamp: ts, body: bodyText };
  }

  async function sendTraceNow(entry) {
    await refreshCallKeyIfNeeded();

    const payload = toTracePayload(entry);
    const body = JSON.stringify(payload);
    const url = new URL(TRACE_ENDPOINT);
    const hdrs = await signedHeaders("POST", url.pathname, new TextEncoder().encode(body));

    if (!hdrs["X-Call-Key"] || !hdrs["X-PW-User"]) {
      log("TRACE blocked: missing call key or user. Open the web app (logged in) and try again.");
      return;
    }

    try {
      const res = await chrome.runtime.sendMessage({
        type: "PW_TRACE",
        endpoint: TRACE_ENDPOINT,
        payload,
        signed: { method: "POST", path: url.pathname, headers: hdrs }
      });

      if (!res?.ok) {
        if (res?.status === 403) {
          log("TRACE -> 403 (unauthorized). Stopping capture and refreshing call key.");
          stop();
          await clearCallKey();
          await ensureCallKeyAuto(true);
        } else if (res?.status) {
          log(`TRACE -> HTTP ${res.status} ${res.body || ""}`.trim());
        } else {
          log(`TRACE -> bg error: ${res?.error || "unknown"}`);
        }
        return;
      }
      log(`TRACE -> ${res.status} ${res.body || ""}`);
    } catch (err) {
      log(`TRACE -> sendMessage error: ${err?.message || err}`);
    }
  }

  // ---------------------------
  // Capture (batching for PW ingest)
  // ---------------------------
  async function toRecord(entry) {
    const { request, response } = entry;
    const base = {
      url: request.url,
      method: request.method,
      requestHeaders: request.headers,
      time: Date.now(),
      resourceType: entry.resourceType,
      status: response && response.status,
      statusText: response && response.statusText,
      responseHeaders: response && response.headers,
      fromCache: entry.fromCache,
      isRedirect: !!(response && response.redirectURL)
    };
    if (captureBodiesEl.checked) {
      try {
        const reqPostData = request.postData;
        if (reqPostData && typeof reqPostData.text === "string") {
          base.requestBody = reqPostData.text;
        }
        await new Promise((resolve) => {
          entry.getContent((content, encoding) => {
            base.responseBody = content;
            base.responseEncoding = encoding || "utf-8";
            resolve();
          });
        });
      } catch (e) {
        base.bodyError = String(e);
      }
    }
    return base;
  }

  function scheduleFlush() {
    if (!flushTimer) flushTimer = setTimeout(doFlush, FLUSH_MS);
  }

  async function doFlush() {
    if (flushTimer) { clearTimeout(flushTimer); flushTimer = null; }
    if (queue.length === 0) return;

    const { pw_token, pw_ingestUrl } = await chrome.storage.session.get(["pw_token","pw_ingestUrl"]);
    if (!pw_token || !pw_ingestUrl) {
      log("Not signed in; dropping batch.");
      queue = [];
      pendingEl.textContent = "0";
      return;
    }

    const payload = {
      source: "permission-works",
      pageUrl: pageUrlCache,
      ts: Date.now(),
      items: queue.splice(0, queue.length)
    };
    pendingEl.textContent = "0";

    try {
      await chrome.runtime.sendMessage({ type: "PW_BATCH", endpoint: pw_ingestUrl, payload, token: pw_token });
      log(`Sent ${payload.items.length} record(s)`);
    } catch (e) {
      log(`Send failed: ${e.message || e}`);
    }
  }

  function onRequestFinished(entry) {
    const { response } = entry;
    if (onlyFailedEl.checked && response && response.status < 400) return;

    // Send single-trace JSON to your server immediately
    sendTraceNow(entry);

    // Existing batching flow for PW ingest
    toRecord(entry).then((rec) => {
      queue.push(rec);
      totalCaptured += 1;
      countEl.textContent = String(totalCaptured);
      pendingEl.textContent = String(queue.length);
      if (queue.length >= BATCH_SIZE) doFlush(); else scheduleFlush();
    });
  }

  // ---------------------------
  // Start/Stop
  // ---------------------------
  async function start() {
    if (enabled) return;

    // Require panel login
    if (!(await ensureAuth())) { loginMsg.textContent = "Please sign in first."; return; }

    // Try a normal key fetch/refresh
    await ensureCallKeyAuto(false);

    // Enforce user match: DevTools user (session) must equal web-app user (local)
    let [{ pw_username }, { pw_webUser, pw_callKey, pw_callKeyExp }] = await Promise.all([
      chrome.storage.session.get(["pw_username"]),
      chrome.storage.local.get(["pw_webUser","pw_callKey","pw_callKeyExp"])
    ]);

    const nowSec = Math.floor(Date.now() / 1000);
    if (!pw_callKey || (pw_callKeyExp && nowSec >= pw_callKeyExp)) {
      log("No valid call key. Open the web app (logged in) and try again.");
      return;
    }

    if (!pw_username || !pw_webUser || pw_username !== pw_webUser) {
      // One-time forced refresh from the active tab
      log(`User mismatch detected (DevTools: ${pw_username || "?"}, Web: ${pw_webUser || "?"}). Refreshing call key...`);
      await clearCallKey();
      await ensureCallKeyAuto(true);

      // re-read after refresh
      [{ pw_username }, { pw_webUser, pw_callKey, pw_callKeyExp }] = await Promise.all([
        chrome.storage.session.get(["pw_username"]),
        chrome.storage.local.get(["pw_webUser","pw_callKey","pw_callKeyExp"])
      ]);

      const now2 = Math.floor(Date.now() / 1000);
      if (!pw_callKey || (pw_callKeyExp && now2 >= pw_callKeyExp)) { log("Still no valid call key after refresh."); return; }
      if (!pw_username || !pw_webUser || pw_username !== pw_webUser) {
        log(`User mismatch remains. DevTools: ${pw_username || "?"}, Web: ${pw_webUser || "?"}. Not starting.`);
        return;
      }
    }

    enabled = true;
    totalCaptured = 0;
    queue = [];
    statusEl.textContent = "Capturing…";
    log("Network capture armed.");
    startBtn.disabled = true;
    stopBtn.disabled = false;
    flushBtn.disabled = false;
    await resolvePageUrl();
    chrome.devtools.network.onRequestFinished.addListener(onRequestFinished);
    startCallKeyRefreshLoop();
    log(`Capture started as ${pw_username}.`);
  }

  function stop() {
    if (!enabled) return;
    enabled = false;
    chrome.devtools.network.onRequestFinished.removeListener(onRequestFinished);
    stopCallKeyRefreshLoop();
    statusEl.textContent = "Idle";
    startBtn.disabled = false;
    stopBtn.disabled = true;
    flushBtn.disabled = true;
    log("Capture stopped.");
    statusEl.textContent = "Idle";
  }

  startBtn.addEventListener("click", start);
  stopBtn.addEventListener("click", stop);
  flushBtn.addEventListener("click", doFlush);



  chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
    if (msg?.type !== 'PW_PANEL_COMMAND') return;
    if (msg.command === 'START_CAPTURE') {
      start().then(() => sendResponse({ ok: true })).catch((e) => sendResponse({ ok: false, error: String(e?.message || e) }));
      return true;
    }
    if (msg.command === 'STOP_CAPTURE') {
      try {
        stop();
        sendResponse({ ok: true });
      } catch (e) {
        sendResponse({ ok: false, error: String(e?.message || e) });
      }
      return true;
    }
    if (msg.command === 'LOG') {
      log(msg.text || '');
      sendResponse({ ok: true });
      return false;
    }
    sendResponse({ ok: false, error: 'Unknown panel command' });
    return false;
  });

  // init
  ensureAuth();
  log("Click the extension toolbar icon once to arm recording, then use the web app Start trace / Stop trace buttons normally.");
})();
